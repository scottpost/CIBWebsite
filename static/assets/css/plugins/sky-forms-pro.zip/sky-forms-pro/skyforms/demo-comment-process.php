<?php
if( isset($_POST['submit']) )
{
	// Your PHP code here
}
?>